<?php

namespace Netatmo\Common;

class NACameraHomeInfo
{
    const CHI_ID = "id";
    const CHI_NAME = "name";
    const CHI_PLACE = "place";
    const CHI_PERSONS = "persons";
    const CHI_EVENTS = "events";
    const CHI_CAMERAS = "cameras";
}

?>
