<?php

namespace Netatmo\Common;

class NACameraAlimSubStatus
{
    const CASS_DEFECT = 1;
    const CASS_OK = 2;
}


?>
