<?php

namespace Netatmo\Common;

class NACameraVideoStatus
{
    const CVS_RECORDING = "recording";
    const CVS_DELETED = "deleted";
    const CVS_AVAILABLE = "available";
    const CVS_ERROR = "error";
}

?>
